#include <iostream>
#include <math.h>
using namespace std;
int main(){
	int a, b, c;
	cout<<"a=";cin>>a;
	cout<<"b=";cin>>b;
	cout<<"c=";cin>>c;
	a=a+b;
	b=a-b;
	a=a-b;
	c=a+c;
	a=c-a;
	c=c-a;
	cout<<a<<endl;
	cout<<b<<endl;
	cout<<c<<endl;
	return 0;
}
