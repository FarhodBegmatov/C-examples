#include<iostream>
#include<math.h>

using namespace std ;

int main () 
{
float a, V, S ;
cout << " Kubning tomonini kiriting :  a = " ;
cin >> a ;

V = pow ( a , 3 ) ;
cout << "Tomoni " << a << " ga teng bo'lgan kubning hajmi :  V = " << V << endl ;

S = 6 * a * a ;
cout << "Tomoni " << a << " ga teng bo'lgan kubning to`la sirti :  S = " << S << endl ;

return 0;
}
