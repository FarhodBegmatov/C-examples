#include<iostream>
#include<math.h>
using namespace std;

int main(){
	float a, S, V;
	cout<<"Kubning qirrasini kiriting:";
	cin>>a;
	S = 6 * a * a;
	V = pow (a , 3) ;
	cout<<"Kubning yuzi:" << S <<endl ;
	cout<<"Kubning hajmi:" << V ;
	return 0;
}
