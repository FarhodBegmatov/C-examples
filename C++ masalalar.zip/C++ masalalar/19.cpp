#include <iostream>
#include <math.h>

using namespace std;

int main(){
	
	float x,y,a=5;
	
	for(x=1; x<=5; x++){
		if(x>3){ y=1/(tan(sqrt(x*x+a)));		}
		
		if(x<3){ y=log(x+fabs(x*x*6))/log(2);		}
		
		else{ y=x+exp(2*x);		}
		
		cout<<"x= "<<x<<"  y="<<y<<endl;
	}
	
	
	
	
	
	return 0;
	
	
}
