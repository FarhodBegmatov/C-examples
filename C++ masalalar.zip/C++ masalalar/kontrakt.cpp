#include<iostream>


using namespace std;

int main(){
	
	int a, b, c, d, p, k, l;
	const int S=10792960;
	cout<<"a=";
	cin>>a;
	cout<<"b=";
	cin>>b;
	d=a*3+(a*0.1+a)*3+(b*0.1+b)*4;
	p=(S/2+(S*0.1+S)/2)-2*(a+a*0.1);
	k=p-d;
	l=(S/2+(S+S*0.1)/2)-4800000;
	cout<<"stipendiya d="<<d<<endl;
	cout<<"kontrakt p="<<p<<endl;
	cout<<"stipendiyali kontrakt k="<<k<<endl;
	cout<<"stipendiyasiz kontrakt l="<<l<<endl;
	return 0;
}

