#include <iostream>
using namespace std;
int main (){
int a[7],i,j,max;
for (i=0; i<7; i++)
{cout<<"a["<<i<<"]=";
cin >>a[i];}
max=a[0];
for(i=0; i<7; i++)
if(max<a[i])
max=a[i];
cout<<max<<endl;
	return 0;
}
