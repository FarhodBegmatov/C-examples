#include <iostream>
using namespace std;

int main ()
{   
	int a[10], i, max;
	for (i=0;i<10;i++)
	{
       cout<<"a["<<i<<"]=";cin>>a[i];
	}
	max=a[0];
	for (i=0;i<10;i+2)
    {
	 if (max<a[i])
	 max=a[i]; 
	 
    }
    cout << max <<endl; 
    return 0;
}
