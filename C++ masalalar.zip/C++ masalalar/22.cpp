#include <iostream>
#include <math.h>

using namespace std;

int main(){
	float y,x,a=13,b=3;
	
	x=6;
do {
		
		if(x==8){			y = pow(x,1/3)-log(a*x);		}
		
		if(x<8){			y = pow(x,1/4)*b+exp(1);		}
		
		else {			y = log(fabs(x-1))/log(2)+exp(2);		}
		
		
		
		cout<<"x = "<<x<<"  y = "<<y<<endl;
		
		x++;
	}while(x<=16);
	
	
		return 0;
}
