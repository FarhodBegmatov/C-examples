#include <iostream>
#include <cstdlib>
#include <math.h>
const float t=2.2;
using namespace std;
int main () {
	float z;
	float x=0.2;
	m:
		if (x<0.5)
		z=pow(log(x),3)+x*x/sqrt(x+1);
		else
		if (x=0.5)
		z=sqrt(x+t)+1/x;
		else
		z=cos(x)+t*pow(sin(x),2);
		cout<<"z= "<<z<<endl;
		x=x+0.2;
		if (x<=2)
		goto m;
		return 0;
}
