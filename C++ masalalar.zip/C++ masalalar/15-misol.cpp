#include<iostream>
#include<math.h>

using namespace std;

int main()
{
	float r, L, S, d;
	const float pi = 3.14;
			
	cout << "Doiraning yuzasi S ning qiymatini kiriting: S = ";
	cin >> S;

	r = sqrt(S / pi);
	
	d = 2 * r;
	
	cout << "Doira radiusi r = " << r << endl;
	
	cout << "Doira diametri d = " << d << endl;
		
		
	return 0;
}
