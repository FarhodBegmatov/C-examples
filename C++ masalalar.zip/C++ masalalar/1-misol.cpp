# include <iostream>
# include <math.h>

using namespace std;

int main ()
{
	int y, x, a;
	cout << "a=";
	cin >> a;
	cout << "x=";
	cin >> x;
	
    y=2*sqrt(2)*pow(cos(a-3.14/4),3)/pow(log10(pow((1+sqrt(7*x)),1/3)),3);
	cout << "y=" << y << endl;
	
	return 0;
	
}
