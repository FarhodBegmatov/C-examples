#include <iostream>
#include <math.h>

using namespace std;

int main(){
	float y,x,a=3,b=0.1;
	
	x=0;
do {
		
		if(x<0.4){			y = pow((x+a*a*a),1/3);		}
		
		if(x>1){			y = 4*x+a*a;		}
		
		else {			y = log(x+a*b)/log(3);		}
		
		
		
		cout<<"x = "<<x<<"  y = "<<y<<endl;
		
		x+=0.5;
	}while(x<=2);
	
	
		return 0;
}
