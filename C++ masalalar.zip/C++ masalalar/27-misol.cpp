#include<iostream>
#include<math.h>

using namespace std;

int main()
{
	float A;
	
	cout << "A ni kiriting: A = ";
	cin >> A;
	
	cout << "y ning kvadrati y2 = " << pow(A, 2) << endl;
	cout << "y ning 4-darajasi y4 = " << pow(A, 4) << endl;
	cout << "y ning 8-darajasi y8 = " << pow(A, 8) << endl;
	return 0;
}
