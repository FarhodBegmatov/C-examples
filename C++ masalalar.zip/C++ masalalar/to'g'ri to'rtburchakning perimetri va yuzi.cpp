#include<iostream>
#include<math.h>

using namespace std ;

int main () 
{
float a, b, P, S ;
cout << " a tomonni kiriting :  a = " ;
cin >> a ;
cout << "b tomonni kiriting :  b = " ;
cin >> b ;

P = 2 * ( a + b ) ;
cout << "Tomonlari " << a << " va " << b << " ga teng bo'lgan to'g'ri to`rtburchakning perimetri :  P = " << P << endl ;

S = a * b ;
cout << "Tomonlari " << a << " va " << b << " ga teng bo'lgan to'g'ri to`rtburchakning yuzi :  S = " << S << endl ;

return 0;
}
