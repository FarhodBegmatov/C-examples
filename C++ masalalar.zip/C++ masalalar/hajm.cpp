#include <iostream>
using namespace std;

float yuza (float a,float b)
{   float s;
     s=a*b;
     return s;
}
    int main ()
    {
	float a,b,s;
    cin>>a;
    cin>>b;
    	cout << yuza(a,b) <<endl;
    	return 0;
	}
