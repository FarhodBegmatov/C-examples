# include <iostream>
# include <math.h>
using namespace std;
int main ()
{
	int n, k;
	float a, x, s;
	cout << "n=";cin >> n;
	cout << "x=";cin >> x;
	a = 1;
	s = a;
	for (k=1;k<=n-1;k++)
	{
		a = a * (-x)*x/((2*k+1)*(2*k+2));
		s = s + a;
	}
	cout << "s=" << s << endl;
	return 0;
}
