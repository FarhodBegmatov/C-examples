#include <iostream>
using namespace std;
int yig (int n)
{
	int s=0;
	while (n!=0)
	{
		s=s+n%10;
		n=n/10;
    }
    return s;
	}
	int main () 
	{
	int a;
    cout <<"sonni kiriting a=";cin >>a;	
	cout << "raqamlar yig`indisi s=" <<yig(a) <<endl;
	return 0;
}
