#include <iostream>
using namespace std;

int main ()
{   const int n=4, m=4;
	int a[n][m], i, j, min, max, b[n];
	for (i=0;i<n;i++){
	for (j=0;j<m;j++)
	{
	    cout << "a["<<i<<"]["<<j<<"]=";cin >> a[i][j];
	}
    }
	for (i=0;i<n;i++){
	max=a[i][0];
	for (j=0;j<m;j++){
	if (max<a[i][j]) max=a[i][j];}	
	b[i]=max;}
	min=b[0];
	for (i=0;i<n;i++){
		if (min>b[i]) min=b[i];
	}
	cout << min << endl;
	return 0;
}
