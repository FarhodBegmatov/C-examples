#include <iostream>
#include <math.h>

using namespace std;

int main(){
	
	
	float y,x;
	const float a = 4;
	
	for(x=0; x<=1.5; x+=0.2){
		if(x==0.4){
			y = tan(x)+(x-a);
		}
		
		else if(x>0.4){
			y = log(fabs(a+x)+6);
		}
		
		else {
			y = exp(x)*a*x;
		}
		cout<<"x = "<<x<<"  y = "<<y<<endl;
		
		
	}
	
	
		return 0;
}
