#include <iostream>
using namespace std;

int kv (int a)
{   int k;
     k=a*a;
     return k;
}
    int main ()
    {
	int a;
    cin>>a;
    	cout << kv(a) <<endl;
    	return 0;
	}
