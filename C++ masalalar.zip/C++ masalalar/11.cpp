#include <iostream>
#include <math.h>

using namespace std;

int main(){
	float y,x,a=10,b=3;
	
	x=2;
do {
		
		if(x>10){			y = log(fabs(x*a-1))+exp(4);		}
		
		if(x<5){			y = pow(fabs(x*x*b-exp(4)),1/3);		}
		
		else {			y = exp(4*sqrt(x))+exp(-5);		}
		
		
		
		cout<<"x = "<<x<<"  y = "<<y<<endl;
		
		x+=1;
	}while(x<=12);
	
	
		return 0;
}
