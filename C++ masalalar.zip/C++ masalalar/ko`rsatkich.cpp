# include <iostream>
using namespace std;
int main ()
{
	float k=25.156;
	float *p(&k);
	cout <<"k o`zgaruvchi qiymati" <<*p<<" , manzili" <<p<<endl;
	
	return 0;
}
