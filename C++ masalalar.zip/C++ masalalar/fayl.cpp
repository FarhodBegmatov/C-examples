#include <iostream>
using namespace std;
int main (){
	FILE *f3;
	int a;
	f3 = fopen ("c:\\hujjat\toq.txt","w");
    for (a=1; a<=100; a++)
	{
	  if (a%2==1)
	  fprintf(f3, "a=%d\t",a);	
    }
	fclose (f3);
	return 0;
}
