#include <iostream>
using namespace std;
int main ()
{
	int s[4][4], i, j, k;
	for(i=0;i<4;i++){
	for(j=0;j<4;j++){
	cout<<"s["<<i<<"]["<<j<<"]=";cin>>s[i][j];}}
	for(i=0;i<4;i++){
	for(j=0;j<4;j++){
	if (s[i][j]>0) s[i][j]=1;}}
	for(i=0;i<4;i++){
	for(j=0;j<4;j++){
	cout<<"s["<<i<<"]["<<j<<"]=" <<s[i][j]<<"\t";
	}
	cout<<"\n\n";}

	return 0;
}
