#include <iostream>
#include <math.h>
using namespace std;

float yuza (float a, float b, float c)
{   float s, p;
     p=(a+b+c)/2; 
     s=sqrt(p*(p-a)*(p-b)*(p-c));
     return s;
}
    int main ()
    {
	float a, b, c;
n:  cout <<"uchburchakning a tomonini kiriting a=";cin>>a;
    cout <<"uchburchakning b tomonini kiriting b=";cin>>b;
    cout <<"uchburchakning c tomonini kiriting c=";cin>>c;
    if (((a+b)>c) and ((a+c)>b) and ((b+c)>a));
    	cout <<"uchburchakning yuzasi s=" <<yuza(a, b, c) <<endl;
    	goto n;
    	return 0;
	}
