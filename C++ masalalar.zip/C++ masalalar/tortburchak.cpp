#include <iostream>
#include <math.h>
using namespace std;

int main(){
	int a, b, p, s;
	cout<<"a ni kiriting a="; cin>>a;
	cout<<"b ni kiriting b="; cin>>b;
	p=2*(a+b);
	s=a*b;
	cout<<"s="<<s<<endl;
	cout<<"p="<<p<<endl;
	return 0;
}
