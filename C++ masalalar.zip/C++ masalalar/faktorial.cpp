# include <iostream>
# include <math.h>
using namespace std;

int main () {
	float x, s, a;
	int k, n;
	cout <<"n=";cin >>n;
	cout <<"x=";cin >>x;
	a = 1;
	s = a;
	for (k=1; k<=n-1; k++)
	{
		a = a*x/(k+1);
		s = s + a;
	}
	cout <<"s=" <<s <<endl;
	system("pause");
	return 0;
}
