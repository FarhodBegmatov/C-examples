#include<iostream>
#include<math.h>

using namespace std ;

int main () 
{
float r1, r2, S ;

cout << " 1-sonni kiriting :  r1 = " ;
cin >> r1 ;
cout << " 2-sonni kiriting :  r2 = " ;
cin >> r2 ;

if ( ( r1 > 0) && ( r2 > 0) )
    {
        S = sqrt ( r1 * r2 ) ;
        cout << " ikki sonning o`rta geometrigi :  S = " << S << endl ;
    }
    else 
    {
        cout << "siz manfiy son kiritdingiz. Musbat son kiriting !!! " << endl ;
         if ( r1 < 0 ) 
             {
    	         cout << " 1-sonni qaytadan kiriting :  r1 = " ;
                 cin >> r1 ;
        
                 S = sqrt ( r1 * r2 ) ;
                 cout << " ikki sonning o`rta geometrigi :  S = " << S << endl ;
	         }
	     else if ( r2 < 0 )
	         {
    	         cout << " 2-sonni qaytadan kiriting :  r2 = " ;
                 cin >> r2 ;
        
                 S = sqrt ( r1 * r2 ) ;
                 cout << " ikki sonning o`rta geometrigi :  S = " << S << endl ;
           	 }
    }
return 0;
}
