#include <iostream>
#include <cstdlib>
#include <math.h>
const float b=0.5;
using namespace std;
int main () {
	float Q;
	float x=-0.2;
	m:
	if (x<0.6)
	Q=b*x*x-log10(b*sqrt(x));
	else
	if (x>0.6)
	Q=cos(x*x)+1;
	else
	Q=b*x*x+log10(b*pow(x,4));
	cout<<"x"<<x<<"Q"<<Q<<endl;
	x=x+0.3;
	if (x<=4)
	goto m;
	system ("pause");
	return 0;
}
