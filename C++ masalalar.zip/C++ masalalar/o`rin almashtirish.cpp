# include <iostream>

using namespace std;

int main ()
{
	int a, b, c;
	cout << "a=";cin >> a;
	cout << "b=";cin >> b;
	cout << "c=";cin >> c;
	a = a + b;
	b = a - b;
	a = a - b;
	c = c + b;
	b = c - b;
	c = c - b;
	cout << "a=" << a << endl;
	cout << "b=" << b << endl;
	cout << "c=" << c << endl;
	return 0;
	
}
