#include <iostream>

using namespace std;

int main () 
{
	int a, b,i;
	
	cout<<"a=";cin>>a;
	cout<<"b=";cin>>b;
    
	for(i=0;i<b;i++)
    
	cout<<"a="<<a<<endl;
    
	return 0;
      	
}
