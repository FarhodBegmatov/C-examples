# include <iostream>
using namespace std;
int EKUB(int a, int b)
{
	if (b==0) return a;
	else return EKUB(b,a%b) ;
}   
    int main ()
    {
    	int a, b;
    	cin >>a;
    	cin >>b;
    	cout <<EKUB(a,b)<<endl;
    	return 0;
	}
