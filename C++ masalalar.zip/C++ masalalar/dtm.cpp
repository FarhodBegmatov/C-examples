#include<iostream>
#include<math.h>
#include<stdio.h>
#include<conio.h>
#include<iomanip>
using namespace std;

int main(){
	l:
	int h = 27000;
	float S[h], a[30][30][30], ball; 
	
	cout << "To'plangan balingizni kiriting: ";
	cin >> ball;
	
	if (ball >= 0 and ball <= 189)
	{
		for ( int i = 0 ; i <= 30 ; i++)
		{
			for ( int j = 0 ; j <= 30 ; j++)
			{
				for ( int k = 0 ; k <= 30 ; k++)
				{
					S[h]= 3.1 * i + 2.1 * j + 1.1 * k ;
					if(S[h] == ball)
					{
						cout << "a["<<i<<"]["<<j<<"]["<<k<<"]=" << setprecision(1) << fixed << S[h] << "\n";	
					};
					
		        }
		    }
		}
	}
	else{
		goto l;
	}

	return 0;
}
