#include <iostream>
using namespace std;
int main ()
{
	int n;
	cout <<"Hafta kunini kiriting"<<endl;
	cin>>n;
	switch (n)
	{
		case 1: cout<<"Dushanba"<<endl; break;
		case 2: cout<<"Seshanba"<<endl; break;
		case 3: cout<<"Chorshanba"<<endl; break;
		case 4: cout<<"Payshanba"<<endl; break;
		case 5: cout<<"Juma"<<endl; break;
		case 6: cout<<"Shanba"<<endl; break;
		case 7: cout<<"Yakshanba"<<endl; break;
		default: cout<<"Bunday hafta kuni yo`q"<<endl;
	}
	system("pause");
	return 0;
}
