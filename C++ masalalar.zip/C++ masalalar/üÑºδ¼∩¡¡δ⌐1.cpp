#include <iostream>
#include <math.h>
using namespace std;
int main (){
	const int a=0.4, b=4.2;
	float x, y, z;
	cout<<"x ni kiriting x=";cin>>x;
	y=(cos(x)+sqrt(a*pow(x,2)+sin(pow(x,3))))/(1/exp(a*x)*sqrt(pow(cos(x),2 )+1/exp(b*x)));
	z=(pow(y,2)*x+pow((a*pow(y,3)+log(a+x*b)),1/5))/(log10(x+y)/log10(b));
	cout<<"y="<<y<<endl;
	cout<<"z="<<z<<endl;
	return 0;
           }
