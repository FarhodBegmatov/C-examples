#include <iostream>
#include <math.h>
using namespace std;
int main(){
	int ab, a, b;
	cout<<"ab=";cin>>ab;
	b=ab%10;
	a=(ab-b)/10;
    a=a+b;
    b=a-b;
    a=a-b;
    a*10+b;
	/*cout<<a<<endl;
	cout<<b<<endl;*/
	cout<<a*10+b;
	return 0;
}
