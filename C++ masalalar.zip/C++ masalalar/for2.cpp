#include <iostream>

using namespace std;

int main () 
{
	int a, b,i, k=0;
	
	cout<<"a=";cin>>a;
	cout<<"b=";cin>>b;
    
	for(i=a;i<=b;i++){ 
    
    cout<<i<<endl;
    k++;}
	cout<<k<<endl;
    
	return 0;
      	
}
