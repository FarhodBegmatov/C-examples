#include <iostream>

using namespace std;

int main () 
{
	float a, s;	
	cout<<"a=";cin>>a;
    
	for(int i=1;i<=10;i++){ 
	
    s=i*a;
    cout<<s<<endl;
    }
   
	return 0;
      	
}
