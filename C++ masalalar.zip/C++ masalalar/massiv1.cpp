#include <iostream>

using namespace std;

int main () 
{
    const int n=3, m=3;
	int a[n][m], i, j, min, max, b[i];
	for(i=0;i<n;i++){
    for(j=0;j<m;j++){
	cout<<"a["<<i<<"]["<<j<<"]=";cin>>a[i][j];
	}}
	for(i=0;i<n;i++){
	min=a[i][0];
	for(j=0;j<m;j++){
		if(min>a[i][j]) min=a[i][j];
		b[i]=min;
	}	
	max=b[0];
	for(i=0;i<n;i++){
		if(max<b[i]) max=b[i];
	}
	cout<<max<<endl;
	}
	   
	return 0;
      	
}
