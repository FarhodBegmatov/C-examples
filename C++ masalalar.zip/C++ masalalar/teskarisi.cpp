#include <iostream>
#include <ctype.h>
#include <string.h>
using namespace std;
int main(){
	char s[10];
	gets(s);
	strrev(s);
	cout<<s;
	
	return 0;
}
