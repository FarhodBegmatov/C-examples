#include<iostream>

using namespace std;

int main()
{
	float A, B, C, D;
	
	cout << "A sonini kiriting A = ";
	cin >> A;
	cout << "B sonini kiriting B = ";
	cin >> B;
	cout << "C sonini kiriting C = ";
	cin >> C;
	D = C;
	C = A;
	A = B;
	B = D;
	
	cout << "A = " << A << endl;
	cout << "B = " << B << endl;
	cout << "C = " << C << endl;
	
	return 0;
}
