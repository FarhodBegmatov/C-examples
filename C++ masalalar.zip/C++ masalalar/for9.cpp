#include <iostream>

using namespace std;

int main () 
{
	float s;
	int n;
	cout<<"n=";cin>>n;
	 //s=0;   
	for(int i=1;i<=n;i++){
    s=s+1/i;}
	cout<<"s="<<s<<endl;
	
    
	return 0;
      	
}
