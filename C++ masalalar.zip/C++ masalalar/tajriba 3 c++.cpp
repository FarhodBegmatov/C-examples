# include <iostream>
# include <math.h>

using namespace std;

int main ()
{
		float y;
		float x=0.7;
		
		n:
		
		if (x>3.5) y=sin(x)*log10(x); 
		
		else 
		
		y=pow(cos(x),2);
		
		cout <<"x=" <<x <<"\ty=" <<y <<endl;
		
		x = x + 0.1;
		
		if (x<=2)
		
		goto n;
		
		return 0;
		
}
