#include<iostream>
#include<math.h>

using namespace std;

int main () 
{
float L, T;
const float pi = 3.14, g = 9.81;
cout << "matematik mayatnikning uzunligini kiriting :  L = ";
cin >> L;

T = 2 * pi * sqrt ( L / g ) ;
cout << L << " uzunlikdagi matematik mayatnikning tebranish davri T = " << T << endl;
return 0;
}
