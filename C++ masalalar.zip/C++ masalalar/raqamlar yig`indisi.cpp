#include <iostream>
#include <math.h>
using namespace std;
int main ()
{
	int a, s, d, k;
	cout <<"a=";cin >> a;
	d=a%10;
	k=a/10;
	s=d+k;
	cout << "s=" <<s <<endl;
	return 0;
}
