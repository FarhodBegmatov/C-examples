#include <iostream>

using namespace std;

int main () 
{
	float a, s, i;	
	cout<<"a=";cin>>a;
    i=0.1;
	do{
	s=i*a;
    cout<<s<<endl;
    i+0.1; }
    while(i<=0.9);
    system("pause");
	return 0;
      	
}
