#include<iostream>
#include<math.h>

using namespace std;

int main () 
{
float t1, t2, v1, v2, t, V;
cout << "1-suvning gradusini kiriting :  t1 = ";
cin >> t1;
cout << "1-suvning hajmini kiriting :  v1 = ";
cin >> v1;
cout << "2-suvning gradusini kiriting :  t1 = ";
cin >> t2;
cout << "2-suvning hajmini kiriting :  v2 = ";
cin >> v2;
V = v2 + v1 ;
t = ( ( v1 + v2 ) * t2 + v1 * t1 ) / ( 2 * v1 + v2 ) ;
cout << "aralashgan suvning umumiy hajmi :  V = " << V << endl ;
cout << V << " hajmli suvning temperaturasi t = " << t << endl;
return 0;
}
