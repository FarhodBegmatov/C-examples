# include <iostream>
# include <math.h>
using namespace std;
int main ()
{
	int n, k;
	float a, x, s;
	cout << "n=";cin >> n;
	cout << "x=";cin >> x;
	a = 1;
	s = a;
	k = 1;
	do
	{
		a = a * (-x)*x/((2*k+1)*(2*k+2));
		s = s + a;
		k++;
	}
	while (k<=n-1);
	cout << "s=" << s << endl;
	return 0;
}
