#include <iostream>

using namespace std;

int main () 
{
	int a, b, i, k=0;
	
	cout<<"a=";cin>>a;
	cout<<"b=";cin>>b;
	for(i=b-1;i>a;i--){ 
    /*for(j=0;j<i;j++){
    if(max>i) {max=i;*/
	cout<<i<<endl; 
    k++;}
	cout<<k<<endl;
    
	return 0;
      	
}
