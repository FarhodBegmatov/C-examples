#include <iostream>
using namespace std;

int main ()
{   const int n=4,m=4;
    int a[n][m], i, j, k, max;
	for (i=0;i<n;i++){
	for (j=0;j<m;j++){
	cout <<"a["<<i<<"]["<<j<<"]=";cin >>a[i][j];}
	}
	if (i==j) {
	
		max=a[0][0];
		for (i=0;i<n;i++)
		{
		   	if (max<a[i][j]) max=a[i][j];
		}}
		cout << max << endl;

	return 0;
}
