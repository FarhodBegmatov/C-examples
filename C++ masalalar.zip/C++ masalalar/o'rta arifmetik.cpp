#include<iostream>
#include<math.h>

using namespace std ;

int main () 
{
float r1, r2, S ;

cout << " 1-sonni kiriting :  r1 = " ;
cin >> r1 ;
cout << " 2-sonni kiriting :  r2 = " ;
cin >> r2 ;

S = ( r1 + r2 ) / 2 ;
cout << " ikki sonning o`rta arifmetigi :  S = " << S << endl ;

return 0;
}
