#include <iostream>
#include <math.h>
using namespace std;
int main(){
	int a, b, c, d;
	cout<<"a=";cin>>a;
	cout<<"b=";cin>>b;
	cout<<"c=";cin>>c;
	d=a;a=c;c=b;b=d;
	cout<<a<<endl;
	cout<<b<<endl;
	cout<<c<<endl;
	return 0;
}
