# include <iostream>

using namespace std;

int main ()
{
	int a, b, c, t;
	cout << "a=";cin >> a;
	cout << "b=";cin >> b;
	cout << "c=";cin >> c;
	t = a;
	a = b;
	b = c;
	c = t;
	cout << "a=" << a << endl;
	cout << "b=" << b << endl;
	cout << "c=" << c << endl;
	return 0;
	
}
