#include <iostream>

using namespace std;

int main ()
{
	int v[10], i, min;
	for (i=0;i<10;i++)
	{
		cout<<"v["<<i<<"]=";cin>>v[i];
	}
	min=v[0];
	for (i=0;i<10;i++)
	{
		if (min>v[i]) min=v[i];
	}
	cout << "eng kichik hadi  " << min <<endl;
	return 0;
}
