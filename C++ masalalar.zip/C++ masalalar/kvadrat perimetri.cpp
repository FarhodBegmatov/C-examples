#include<iostream>
#include<math.h>

using namespace std ;

int main () 
{
float a, P ;
cout << "Kvadratning tomonini kiriting :  a = " ;
cin >> a ;
P = 4 * a ;
cout << "Tomoni " << a << " ga teng bo'lgan kvadratning perimetri :  P = " << P << endl ;
return 0;
}
