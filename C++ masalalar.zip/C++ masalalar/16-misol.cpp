#include<iostream>
#include<math.h>

using namespace std;

int main()
{
	float X1, X2;
			
	cout << "Son o'qidagi 1-nuqtani kiriting X1 = ";
	cin >> X1;

	cout << "Son o'qidagi 2-nuqtani kiriting X2 = ";
	cin >> X2;
	
	cout << "Ikki nuqta orasidagi masofa - " << fabs(X2 - X1) << endl;
		
		
	return 0;
}
