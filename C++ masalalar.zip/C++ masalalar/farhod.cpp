#include <iostream>

using namespace std;

int main ()
{
	int s[4][4], i, j, k;
	
	for(i=0;i<4;i++){
	for(j=0;j<4;j++){
	
	cout<<"s["<<i<<"]["<<j<<"]=";cin>>s[i][j];}}
	k=0;
	
	for(i=0;i<4;i++){
	for(j=0;j<4;j++){
		
	if (i==j) {k=k+s[i][j];}}}
	cout <<"k="<<k<<endl;
	return 0;
}
