#include <iostream>
using namespace std;

int main ()
{   
	int a[4], b[4], i;
	for (i=0;i<4;i++){
     cout<<"a["<<i<<"]=";
	 cin>>a[i];
	}
	
	
/*	for (i=0;i<4;i++){
    	if (a[i]%2==1){
			b[i]=a[i];
	}*/
	for (i=0;i<4;i++){
	cout<<"a["<<i<<"]="<<a[i]<<"\t";}
	cout <<"\n\n";
	return 0;	 
}
