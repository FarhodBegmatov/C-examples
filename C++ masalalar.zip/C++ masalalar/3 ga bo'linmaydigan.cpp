#include <iostream>
using namespace std;
int main ()
{
	FILE *f, *f1;
	f = fopen ("c:\\hujjat\\son.txt", "r");
	f1 = fopen ("c:\\hujjat\\yig`indi.txt", "w");
	int n, i, s=0;
	while (1){
	n=fscanf(f, "%d", &i);
	if (n!=1) break;
	s=s+i;
	cout<<i<<endl;
    }
    fprintf (f1, "%d", s);
	fclose(f1);
	return 0;
}
