#include<iostream>
#include<math.h>

using namespace std;

int main()
{
	float R, L, S;
	const float pi = 3.14;
			
	cout << "Doiraning uzunligi L ning qiymatini kiriting: L = ";
	cin >> L;

	R = L / (2 * pi);
	
	S = pi * R * R;
	
	cout << "Doira radiusi R = " << R << endl;
	
	cout << "Doira yuzasi S = " << S << endl;
		
		
	return 0;
}
