#include<iostream>
#include<math.h>

using namespace std;

int main()
{
	float R1, R2, S1, S2, S3;
	const float pi = 3.14;
	
	l:
		
	cout << "R1 ning qiymatini kiriting: R1 = ";
	cin >> R1;

	cout << "R2 ning qiymatini kiriting: (R2 < R1) R2 = ";
	cin >> R2;
	
	if ( R1 > R2) 
	{

	S1 = pi * R1 * R1;
	S2 = pi * R2 * R2;
	
	cout << "S1 = " << S1 << endl << "S2 = " << S2 << endl;
	
	S3 = S1 - S2;
	
	cout << "S3 = " << S3 << endl;
	}
	else 
	{
		cout << " R2 < R1 bo'lishi kerak, qaytadan kiriting!!!" << endl;
		goto l;
	}
	
	
		
	return 0;
}
