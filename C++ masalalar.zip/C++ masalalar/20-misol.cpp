#include<iostream>
#include<math.h>

using namespace std;

int main()
{
	float x1, x2, y1, y2;
		
	cout << "A nuqtaning x koordintasini kiriting x1 = ";
	cin >> x1;
	cout << "A nuqtaning y koordintasini kiriting y1 = ";
	cin >> y1;
	
	cout << "B nuqtaning x kooordinatasini kiriting x2 = ";
	cin >> x2;
	cout << "B nuqtaning y kooordinatasini kiriting y2 = ";
	cin >> y2;
	

	cout << "A va B nuqtalar orasidagi masofa - " << sqrt(pow((x2 - x1), 2) + pow((y2 - y1), 2)) << endl;
		
	
	return 0;
}
