#include<iostream>
#include<math.h>

using namespace std;

int main()
{
	float x1, x2, x3, x4, y1, y2, y3, y4, a, b, p, S;
		
	cout << "A nuqtaning x koordintasini kiriting x1 = ";
	cin >> x1;
	cout << "A nuqtaning y koordintasini kiriting y1 = ";
	cin >> y1;
	
	cout << "B nuqtaning x kooordinatasini kiriting x2 = ";
	cin >> x2;
	cout << "B nuqtaning y kooordinatasini kiriting y2 = ";
	cin >> y2;
	
	cout << "C nuqtaning x kooordinatasini kiriting x3 = ";
	cin >> x3;
	cout << "C nuqtaning y kooordinatasini kiriting y3 = ";
	cin >> y3;
	
	cout << "D nuqtaning x kooordinatasini kiriting x4 = ";
	cin >> x4;
	cout << "D nuqtaning y kooordinatasini kiriting y4 = ";
	cin >> y4;

	a = sqrt(pow((x2 - x1), 2) + pow((y2 - y1), 2));
	b = sqrt(pow((x3 - x2), 2) + pow((y3 - y2), 2));

	cout << "AB kesmaning uzunligi a = " << a << endl;
		
	cout << "BC kesmaning uzunligi b = " << b << endl;
	
	cout << "To'g'ri to'rtburchakning perimetri p = " << 2 * ( a + b ) << endl;
	cout << "To'g'ri to'rtburchakning yuzi S = " << a * b << endl;
	
	return 0;
}
