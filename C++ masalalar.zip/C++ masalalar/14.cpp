#include <iostream>
#include <math.h>

using namespace std;

int main(){
	float y,x;
	const float a = 4,b=3;
	x=0;
	while(x<=2){
		
		if(x<1){			y = 6*x-a*x*x+cos(x);		}
		
		else if(x==1){			y = sqrt(x*x+exp(-2))*fabs(x);		}
		
		else {			y = exp(3*x*fabs(15-x*x)+b);		}
		
		
		
		cout<<"x = "<<x<<"  y = "<<y<<endl;
		
		x=x+0.2;
	}
	
	
		return 0;
}
