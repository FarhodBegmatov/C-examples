#include <iostream>
using namespace std;

int main ()
{   
	int a[100][100], i, j,c,n, m;
	cout<<"Matrissa elementlar sonini kiriting: n=";
	cin>>n;
	cout<<"Matrissa elementlar sonini kiriting: m=";
	cin>>m;
	for (i=0;i<n;i++){
	for (j=0;j<m;j++)
	{
	    cout << "a["<<i<<"]["<<j<<"]=";cin >> a[i][j];
	}
    }
	for (i=0;i<n;i++){
		for(j=0;j<m;j++){
		
	cout<<"a["<<i<<"]["<<j<<"]="<<a[i][j]<<"\t";}
	cout <<"\n\n";}
	
	return 0;
}
