#include <iostream>
#include <math.h>
using namespace std;
int main(){
	int a, c;
	cout<<"a=";cin>>a;
	cout<<pow(a,2)<<",\t"<<pow(a,4)<<",\t"<<pow(a,8)<<endl;
	return 0;
}
