#include <iostream>
#include <cstdlib>
#include <math.h>
using namespace std;
int main() {
	const float a=-0.5, b=2;
	float y,t;
	m:
	if(t<1)
	y=1;
	else
	if(t>2)
	y=exp(a*t)*cos(b*t);
	else
	y=a*pow(t,2)*log(t);
	cout<<"t="<<t<<"\ty="<<y<<endl;
	t=t+0.15;
	if(t<=3)
	goto m;
	system ("pause");
	return 0;
}
