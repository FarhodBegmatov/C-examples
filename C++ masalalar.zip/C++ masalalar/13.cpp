#include <iostream>
#include <math.h>

using namespace std;

int main(){
	
	float x,y,a=10,b=13;
	
	for(x=2; x<=8; x=x+0.5){
		if(x<4){ y=a*sqrt(x+1);		}
		
		if(x>6){ y=a*a-b*b-x*x;		}
		
		else{ y=a*x*x-b;		}
		
		cout<<"x= "<<x<<"  y="<<y<<endl;
	}
	
	
	
	
	
	return 0;
	
	
}
