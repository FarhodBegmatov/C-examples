# include <iostream>
# include <math.h>
using namespace std;

int main () {
	float x, s, a;
	int k, n;
	cout <<"n=";cin >>n;
	cout <<"x=";cin >>x;
	a = sin(x);
	s = a;
	for (k=1; k<=n-1; k++)
	{
		a = a*(sin((2*k+1)*x)*(2*k-1))/((2*k+1)*sin((2*k-1)*x));
		s = s + a;
	}
	cout <<"s=" <<s <<endl;
	return 0;
}
