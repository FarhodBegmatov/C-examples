#include <iostream>
#include <math.h>

using namespace std;

int main(){
	
	float x,y,a=5,b=3;
	
	for(x=-1; x<=9; x++){
		if(x>7){ y=sqrt(x)+log(sqrt(x));		}
		
		if(x<3){ y=fabs(x*x*x+exp(x))-b;		}
		
		else{ y=exp(x)+a*log(x)/log(2);;		}
		
		cout<<"x= "<<x<<"  y="<<y<<endl;
	}
	
	
	
	
	
	return 0;
	
	
}
