#include<iostream>
#include<math.h>

using namespace std;

int main()
{
	float A, B, C;
		
	k:
		
	cout << "Son o'qidagi 1-nuqtani kiriting A = ";
	cin >> A;

	cout << "Son o'qidagi 2-nuqtani kiriting B = ";
	cin >> B;
	
	cout << "Son o'qidagi 3-nuqtani kiriting C = ";
	cin >> C;
	
	if (C > A && C < B)
	{
	cout << "AC kesmaning uzunligi AC = " << fabs(C - A) << endl;
		
	cout << "BC kesmaning uzunligi BC = " << fabs(C - B) << endl;
	
	cout << "AC va BC kesmalar uzunligining ko'paytmasi - " << fabs(C - A) * fabs(C - B) << endl;
	}
	else
	{
		cout << "(C > A va C < B) shart qanoatlantirilsin, qaytadan kiriting!!!" << endl;
		goto k;
	}
	return 0;
}
