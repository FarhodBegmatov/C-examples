#include <iostream>

using namespace std;

int main () 
{
	int a, b, i, s=0;
	
	cout<<"a=";cin>>a;
	cout<<"b=";cin>>b;
    
	for(i=a;i<b;i++){
    s+=i;}
	cout<<"s="<<s<<endl;
	
    
	return 0;
      	
}
