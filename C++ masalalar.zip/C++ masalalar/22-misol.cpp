#include<iostream>

using namespace std;

int main()
{
	float A, B, C;
	
	cout << "A sonini kiriting A = ";
	cin >> A;
	cout << "B sonini kiriting B = ";
	cin >> B;
	
	C = A;
	A = B;
	B = C;
	
	cout << "A = " << A << endl;
	cout << "B = " << B << endl;
	return 0;
}
