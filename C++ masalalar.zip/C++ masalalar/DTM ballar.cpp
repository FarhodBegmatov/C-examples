#include<iostream>
#include<math.h>
#include<stdio.h>
using namespace std;

int main(){
	float S[27], a[3][3][3];
	  for ( int h = 1 ; h <= 120 ; h++){ 
	  for (int l=1; l<=40; l++){
				 for (int t=1; t<=3; t++){ 
				 for (int m=1; m<=3; m++){  
	for ( int i = 1 ; i <= 3 ; i++){
		for ( int j = 1 ; j <= 3 ; j++){
			for ( int k = 1 ; k <= 3 ; k++){
				S [h]= 3.1 * i + 2.1 * j + 1.1 * k ;
				
				
				   
				     
					//cout << "umumiy natija : S = " << S <<endl;
					//cout << i << " " << j << " " << k << endl ;
					a[l][t][m] = S[h];
				     cout << "a["<<i<<"]["<<j<<"]["<<k<<"] = " << a[l][t][m] << "\t";		                    
	           }
	           cout<<"\n";
	           }
	           
			}
		}
	}
		}
	}

	return 0;
}
