#include<iostream>
#include<math.h>

using namespace std ;

int main () 
{
float a, S ;
cout << "Kvadratning tomonini kiriting :  a = " ;
cin >> a ;
S = a * a ;
cout << "Tomoni " << a << " ga teng bo'lgan kvadratning yuzi :  S = " << S << endl ;
return 0;
}
