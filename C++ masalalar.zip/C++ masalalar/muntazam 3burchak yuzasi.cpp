#include<iostream>
#include<math.h>
using namespace std;

int main(){
	float a, b, c, S;
	cout << "muntazam uchburchakni tomonini kiriting: a = ";
	cin >> a;
	S = ( a * a ) * sqrt(3) / 4;
	cout << "Ucburchakning yuzasi : S = " << S << endl;
	return 0;
}
