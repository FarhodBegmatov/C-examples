#include<iostream>
#include<math.h>

using namespace std;

int main () 
{
float X, Y, R;
cout << "1-sonni kiriting :  X = ";
cin >> X;
cout << "2-sonni kiriting :  Y = ";
cin >> Y;

R = ( fabs ( X ) - fabs ( Y ) ) / ( 1 + fabs ( X * Y ) ) ;

cout << " Natija :  R = " << R << endl;
return 0;
}
