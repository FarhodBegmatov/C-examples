#include <iostream>
#include <math.h>

using namespace std;

int main(){
	
	float x,y,a=12,b=0.5;
	
	for(x=2; x<=10; x++){
		if(x<5){ y=pow(log(x),3)+pow(x,1/5);		}
		
		if(x==5){ y=sqrt(pow(x,5)+1)+a;		}
		
		else{ y=b*exp(x)+log(x)/log(12);;		}
		
		cout<<"x= "<<x<<"  y="<<y<<endl;
	}
	
	
	
	
	
	return 0;
	
	
}
