#include <iostream>
using namespace std;

float yuza (float r)
{   const float pi=3.14;
    float s;
     s=pi*r*r;
     return s;
}
    int main ()
    {
	float r;
     cout <<"r="; cin>>r;
    	cout <<"s=" << yuza(r) <<endl;
    	return 0;
	}
