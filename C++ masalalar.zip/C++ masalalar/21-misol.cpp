#include<iostream>
#include<math.h>

using namespace std;

int main()
{
	float x1, x2, x3, x4, y1, y2, y3, y4, a, b, c, p, S;
		
	cout << "A nuqtaning x koordintasini kiriting x1 = ";
	cin >> x1;
	cout << "A nuqtaning y koordintasini kiriting y1 = ";
	cin >> y1;
	
	cout << "B nuqtaning x kooordinatasini kiriting x2 = ";
	cin >> x2;
	cout << "B nuqtaning y kooordinatasini kiriting y2 = ";
	cin >> y2;
	
	cout << "C nuqtaning x kooordinatasini kiriting x3 = ";
	cin >> x3;
	cout << "C nuqtaning y kooordinatasini kiriting y3 = ";
	cin >> y3;

	a = sqrt(pow((x2 - x1), 2) + pow((y2 - y1), 2));
	b = sqrt(pow((x3 - x2), 2) + pow((y3 - y2), 2));
	c = sqrt(pow((x3 - x1), 2) + pow((y3 - y1), 2));
	p = 2 * ( a + b );
	float yp = p / 2;
	S = sqrt(yp * (yp - a) * (yp - b) * (yp - c));
	cout << "AB kesmaning uzunligi a = " << a << endl;	
	cout << "BC kesmaning uzunligi b = " << b << endl;
	cout << "AC kesmaning uzunligi c = " << c << endl;
	cout << "Uchburchakning perimetri p = " << p << endl;
	cout << "Uchburchakning yuzi S = " << S << endl;
	
	return 0;
}
