#include <iostream>
using namespace std;
int rek (int n)
{
	if (n==0) return 0;
	else
	return n%10+rek(n/10);	
	}
	int main () 
	{
	int a;
    cout <<"sonni kiriting a=";cin >>a;	
	cout << "raqamlar yig`indisi s=" <<rek(a) <<endl;
	return 0;
}
