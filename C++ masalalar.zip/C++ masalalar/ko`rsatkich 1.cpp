# include <iostream>
using namespace std;
int mai ()
{
	int a=10, b=46;
	int *p=&b, *q=&a;
	cout <<"a o`zgaruvchi qiymati" <<*q<<" , manzili" <<q<<endl;
	cout <<"b o`zgaruvchi qiymati" <<*p<<" , manzili" <<p<<endl;
	return 0;
}
