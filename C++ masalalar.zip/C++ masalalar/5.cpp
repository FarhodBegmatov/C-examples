#include <iostream>
#include <math.h>

using namespace std;

int main(){
	float y,x,a=6,b=2.5;
	
	x=0;
do {
		
		if(x>7){			y = pow(x,2)*sqrt(pow(x, 3)+a);		}
		
		if(x<1){			y = 6+x;		}
		
		else {			y = exp(b*x)+cos(b*x);		}
		
		
		
		cout<<"x = "<<x<<"  y = "<<y<<endl;
		
		x+=1;
	}while(x<=10);
	
	
		return 0;
}
