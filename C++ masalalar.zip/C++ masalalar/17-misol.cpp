#include<iostream>
#include<math.h>

using namespace std;

int main()
{
	float A, B, C;
			
	cout << "Son o'qidagi 1-nuqtani kiriting A = ";
	cin >> A;

	cout << "Son o'qidagi 2-nuqtani kiriting B = ";
	cin >> B;
	
	cout << "Son o'qidagi 3-nuqtani kiriting C = ";
	cin >> C;
	
	cout << "AC kesmaning uzunligi AC = " << fabs(C - A) << endl;
		
	cout << "BC kesmaning uzunligi BC = " << fabs(C - B) << endl;
	
	cout << "AC va BC kesmalari uzunliklarining yig'indisi - " << fabs(C - A) + fabs(C - B) << endl;	
	return 0;
}
