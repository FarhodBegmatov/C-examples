#include<iostream>
#include<math.h>
using namespace std;

int main(){
	float a, b, c, S;
	cout << "a katetni kiriting: ";
	cin >> a;
	cout << "b katetni kiriting: ";
	cin >> b;
	c =sqrt ( pow ( a , 2 ) + pow ( b , 2 ) ) ;
	S = a + b + c ;
	cout << "c gipotenuzaning qiymati : c = " << c << endl ;
	cout << "Ucburchakning perimetri : S = " << S ;
	return 0;
}
