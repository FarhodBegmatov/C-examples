#include <iostream>
#include <math.h>

using namespace std;

int main(){
	float y,x,a=4;
	
	
 for(x=0; x<=1; x+=0.1){
		
		if(x<0.)			
				y = sqrt(a*exp(x)+4);		
		
		if(x==1)			
				y = 1/(pow((sin(sqrt(x))),2));		
		
		if(x>0.1)			
				y = pow(cos(sqrt(x)),2)*a;		
		
		
		
		cout<<"x = "<<x<<"  y = "<<y<<endl;
		
	
	}
	
	
		return 0;
}
