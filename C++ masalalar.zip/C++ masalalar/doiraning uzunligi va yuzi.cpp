#include<iostream>
#include<math.h>

using namespace std ;

int main () 
{
float r, L, S ;
const float pi = 3.14 ;

cout << " doiraning radiusini kiriting :  r = " ;
cin >> r ;

L = 2 * pi * r ;
cout << "Diametri " << r << " ga teng bo'lgan doiraning uzunligi :  L = " << L << endl ;

S = pi * r * r ;
cout << "Tomoni " << r << " ga teng bo'lgan doiraning yuzi :  S = " << S << endl ;

return 0;
}
