#include<iostream>
#include<math.h>

using namespace std;

int main () 
{
float R1, R2, R3, R;
cout << "1-qarshilikni kiriting :  R1 = ";
cin >> R1;
cout << "2-qarshilikni kiriting :  R2 = ";
cin >> R2;
cout << "3-qarshilikni kiriting :  R3 = ";
cin >> R3;
R = R1 * R2 * R3 / ( R1 * R2 + R1 * R3 + R2 * R3 ) ;

cout << " Parallel ulangan qarshiliklarning umumiy qarshiligi  R = " << R << endl;
return 0;
}
