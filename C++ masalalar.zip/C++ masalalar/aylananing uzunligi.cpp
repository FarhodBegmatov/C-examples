#include<iostream>
#include<math.h>

using namespace std ;

int main () 
{
float d, L ;
const float pi = 3.14 ;
cout << "Aylananing diametrini kiriting :  d = " ;
cin >> d ;
L = pi * d ;
cout << "Diametri " << d << " ga teng bo'lgan aylananing uzunligi :  L = " << L << endl ;
return 0;
}
