#include <iostream>
using namespace std;

int katta (int a, int b)
{   int k;
     if (a>b) k=a;
     else k=b;
     return k;
}
    int main ()
    {
    	cout << katta (7,5) <<endl;
    	return 0;
	}
