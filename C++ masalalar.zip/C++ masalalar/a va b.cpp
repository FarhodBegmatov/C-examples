#include <iostream>
#include <math.h>
using namespace std;
int main(){
	int a, b, c;
	cin>>a;
	cin>>b;
	c=a;a=b;b=c;
	cout<<a<<endl;
	cout<<b<<endl;
	return 0;
}
