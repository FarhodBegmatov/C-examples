#include <iostream>
#include <string.h>
using namespace std;
int main ()
{
	char q1[100], q2[100], q3[100],q4[100],q5[100];
	gets(q1);
	gets(q2);
	gets(q3);
	gets(q4);
	gets(q5);
	strcat (q1, q2);
	strcat (q1, q3);
	strcat (q1, q4);
	strcat (q1, q5);
	cout <<q1<<endl;
	return 0;
}
