#include <iostream>

using namespace std;

int main () 
{
	float a, s, i;	
	cout<<"a=";cin>>a;
    
	for(i=1.2;i<=2;i+0.2){ 
	s=i*a;
    cout<<s<<endl;
    }
   
	return 0;
      	
}
