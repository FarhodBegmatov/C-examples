#include<iostream>
#include<math.h>
using namespace std;
int main ()
{
	const float x=2.94	;
	float p;
	p=log((x+sqrt(1+x*x))/x)+pow(tan((1-exp(x))/(1+exp(x))),3);
	cout<<"p = "<<p<<endl;
	return 0;
}
