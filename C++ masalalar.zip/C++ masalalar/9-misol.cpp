#include<iostream>
#include<math.h>

using namespace std;

int main()
{
	  	float a, P;
	
	cout << "a ni kiriting: ";
	cin >> a;
	
	P = 4 * a;
	
	cout << " Perimetr P = " << P << endl;
	
	return 0;
}
