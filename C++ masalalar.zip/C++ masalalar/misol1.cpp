#include <iostream>
using namespace std;
int main (){
	FILE *f;
	f = fopen("c:\\dastur\\hujjat\\misol1.txt" , "w");
	for (int i=1; i<=50; i++){
		if (i%7!=0) fprintf(f, "%d\n",i);
	}
	fclose(f);
	return 0;
}
