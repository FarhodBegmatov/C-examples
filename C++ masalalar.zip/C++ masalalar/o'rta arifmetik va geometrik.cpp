#include<iostream>
#include<math.h>
using namespace std;

int main () {
	float a , b , c, S ;
	k:
	cout << endl ;
	cout << "a sonni kiriting: " ;
	cin >> a ;
	cout << "b sonni kiriting: " ;
	cin >> b ;
	if ( ( a > 0 ) && ( b > 0 ) ) 
	{
	  c = ( a + b ) / 2 ;
	  S = sqrt ( a * b) ;
	cout << "O'rta arifmetigi c = " << c << endl ;
	cout << "O'rta geometrigi S = " << S ;
	}
	else cout << "Siz manfiy son kiritdingiz. Musbat son kiriting!!!" << endl ;
	goto k;
	return 0 ;
}
