#include <iostream>
#include <math.h>

using namespace std;
int main() {
	int k, n; 
	float x, a, s;
	cout<<"x="; cin>>x;
	cout<<"n="; cin>>n;
	a=pow(x,2)/2; 
	s=a;
	for(k=1; k<=n-1; k++){
		a=a*(pow(x,2)*2*k*(1-2*k))/(2*k+2)*(2*k+1);
		s=s+a;
	} cout<<"Natija S="<<s<<endl;
	
	return 0;
}
