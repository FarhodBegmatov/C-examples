# include <iostream>
using namespace std;
int main ()
{  
    int i,s;
	int a[10];
	cin >> a[i];
	for (i=2; i<=6; i++)
	{
	s=0;
	cout<<"a["<<i<<"]=";
	cin >> a[i];
	s=s+a[i];
	}
	//cin >> a[i];
	cout <<"s="<<s <<endl;
	return 0;
}
