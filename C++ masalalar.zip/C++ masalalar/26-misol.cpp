#include<iostream>
#include<math.h>

using namespace std;

int main()
{
	float x, y;
	
	cout << "x ni kiriting: x = ";
	cin >> x;
	
	y = 3 * pow(x, 6) - 6 * x * x - 7;
	
	cout << "y = " << y << endl;
	
	return 0;

}
