#include <iostream>
using namespace std;

int main ()
{   int n, m;
    cout<<"n ni kiriting:";
    cin>>n;
    cout<<"m ni kiriting:";
    cin>>m;
	int a[n][m], i, j, s, k, b;
	for (i=0;i<n;i++){
	for (j=0;j<m;j++)
	{
	    cout << "a["<<i<<"]["<<j<<"]=";cin >> a[i][j];
	}
	
    }
    k=0;
	for(i=0; i<n;i++){
	
	s=0;
	for (j=0;j<m;j++){
	s+=a[i][j];
	}
	cout<<i<<"\tsatrdagi elementlar yig'indisi:\t"<<s<<endl;
	for (j=0;j<m;j++){
	k+=a[i][j];
		}
		cout<<i<<"\tsatrdagi elementlar yig'indisi:\t"<<k<<endl;
		for (j=0;j<m;j++){
	b+=a[i][j];
	}
		cout<<i<<"\tsatrdagi elementlar yig'indisi:\t"<<b<<endl;
}
	return 0;
}
