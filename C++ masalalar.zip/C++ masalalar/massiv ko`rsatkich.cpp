# include <iostream>
using namespace std;
int main ()
{
    int a[10];
    int *p=a;
	cout <<"manzili" <<p<<endl;
	
	return 0;
}
