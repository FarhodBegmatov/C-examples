#include<iostream>
#include<math.h>
using namespace std;

int main(){
	float t, g = 10, H ;
	cout << "H balandlikni kiriting: ";
	cin >> H;
	t = sqrt ( 2 * H / g );
	cout << "Erkin tushgan toshning uchish uzoqligi : t = " << t << endl ;
	return 0;
}
