#include<iostream>
#include<math.h>

using namespace std;

int main()
{
	float A;
	
	cout << "A ni kiriting: A = ";
	cin >> A;
	
	cout << "A ning kvadrati A2 = " << pow(A, 2) << endl;
	cout << "A ning 3-darajasi A3 = " << pow(A, 3) << endl;
	cout << "A ning 5-darajasi A5 = " << pow(A, 5) << endl;
	cout << "A ning  10-darajasi A10= "<< pow(A, 10)<< endl;
	cout << "A ning 15 darajasi A15= "<< pow(A, 15)<< endl; 
	 return 0;
}
