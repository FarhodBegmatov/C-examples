# include <iostream>
# include <math.h>
using namespace std;
int main ()
{
	float x, s, a;
	int k, n;
	cout << "n=";cin >> n;
	cout << "x=";cin >> x;
	a = x/6;
	s = a;
	for (k=1; k<=n-1; k++)
	{
		a = a*x*(k+1)/(2*(2*k+3)*k*k);
		s = s + a;
	}
	cout << "s=" << s <<endl;
	return 0;
}
