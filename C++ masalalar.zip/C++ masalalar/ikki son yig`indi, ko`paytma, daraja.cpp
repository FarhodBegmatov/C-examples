#include<iostream>
#include<math.h>

using namespace std ;

int main () 
{
float r1, r2, S, P, a, b ;
l:
cout << " 1-sonni kiriting :  r1 = " ;
cin >> r1 ;
k:
cout << " 2-sonni kiriting :  r2 = " ;
cin >> r2 ;

if ( ( r1 != 0 ) && ( r2 != 0) )
    {
    	        S = r1 + r2 ;
                
                 P = r1 * r2 ;
                 
                 a = pow ( r1 , 2 ) ;
                 
                 b = pow ( r2 , 2 ) ;
                 
				 cout << " ikki sonning yig`indisi :  S = " << S << endl ;
				 cout << " ikki sonning ko`paytmasi :  P = " << P << endl ;
				 cout << " r1 sonining darajasi :  a = " << a << endl ;
				 cout << " r2 sonining darajasi :  b = " << b << endl ;
	}
	     else 
	         {
    	        cout << "siz 0 sonini kiritdingiz. 0 dan farqli son kiriting !!! " << endl ;
    	        goto l ;
           	 }
           	 	
return 0;
}
