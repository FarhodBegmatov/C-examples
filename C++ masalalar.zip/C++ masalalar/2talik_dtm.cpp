#include<iostream>
#include<math.h>
#include<stdio.h>
#include<conio.h>
#include<iomanip>
using namespace std;

int main(){
	l:
	int h = 900;
	float S[h], a[30][30], ball; 
	
	cout << "To'plangan balingizni kiriting: ";
	cin >> ball;
	
	if (ball >= 0 and ball <= 189)
	{
		for ( int i = 0 ; i <= 30 ; i++)
		{
			for ( int j = 0 ; j <= 30 ; j++)
			{
					S[h] = 3.2 * i + 3.1 * j;
					if(S[h] == ball)
					{
						cout << "a["<<i<<"]["<<j<<"]=" << setprecision(1) << fixed << S[h] << "\n";	
					};
		    }
		}
	}
	else{
		goto l;
	}

	return 0;
}
