#include <iostream>
using namespace std;

int main ()
{   const int n=4;
	int a[n][n], i, j, min, b[n];
	for (i=0;i<n;i++){
	for (j=0;j<n;j++)
	{
	    cout << "a["<<i<<"]["<<j<<"]=";cin >> a[i][j];
	}
    }
	for (i=0;i<n;i++){
	b[i]=a[i][0];
	for (j=0;j<n;j++){
	if (b[i]<a[i][j]) b[i]=a[i][j];}	
	}
	min=b[0];
	for (i=0;i<n;i++){
		if (min>b[i]) min=b[i];
	}
	cout << min << endl;
	return 0;
}
