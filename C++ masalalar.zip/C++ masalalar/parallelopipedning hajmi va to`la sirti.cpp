#include<iostream>
#include<math.h>

using namespace std ;

int main () 
{
float a, b, c, V, S ;
cout << " a tomonni kiriting :  a = " ;
cin >> a ;
cout << "b tomonni kiriting :  b = " ;
cin >> b ;
cout << "c tomonni kiriting :  c = " ;
cin >> c ;
V = a * b * c ;
cout << "Tomonlari " << a << " , " << b << " va " << c << " ga teng bo'lgan parallelopipedning hajmi :  V = " << V << endl ;

S = 2 * ( a * b + b * c + a * c ) ;
cout << "Tomonlari " << a << " , " << b << " va " << c << " ga teng bo'lgan parallelopipedning to`la sirti :  S = " << S << endl ;

return 0;
}
