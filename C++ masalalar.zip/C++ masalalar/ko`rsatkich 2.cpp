# include <iostream>
using namespace std;
int main ()
{   
    int a=10;
    int *p(&a);
	int *t=p;
	cout <<"p o`zgaruvchi qiymati" <<*t<<" , manzili" <<t<<endl;
	
	return 0;
}
